import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionSupport;

@Controller("voiceRecordAction")
@Scope("prototype")
public class VoiceRecordAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5300711145543728671L;

	private VoiceRecordService voiceRecordService;

	private String fileuploadFileName;

	private File fileupload; // 和JSP中input标记name同名

	private File file;

	private String value1;

	private String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getValue1() {
		return value1;
	}

	public void setValue1(String value1) {
		this.value1 = value1;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public File getFileupload() {
		return fileupload;
	}

	public void setFileupload(File fileupload) {
		this.fileupload = fileupload;
	}

	public String getFileuploadFileName() {
		return fileuploadFileName;
	}

	public void setFileuploadFileName(String fileuploadFileName) {
		this.fileuploadFileName = fileuploadFileName;
	}

	private List<VoiceRecord> list;

	public List<VoiceRecord> getList() {
		return list;
	}

	public void setList(List<VoiceRecord> list) {
		this.list = list;
	}

	@Resource
	public void setVoiceRecordService(VoiceRecordService voiceRecordService) {
		this.voiceRecordService = voiceRecordService;
	}

	public String test() {
		System.out.println(file);
		String name = new Date().getTime() + ".mp3";
		String savePath = ServletActionContext.getServletContext().getRealPath(
				"/upload/member/voice/" + name);
		System.out.println(savePath);
		try {
			FileUtils.copyFile(file, new File(savePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(value1);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=UTF-8");
		try {
			response.getWriter().write("success");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public String uploadFile() {
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=UTF-8");

		String extName = ""; // 保存文件拓展名
		String newFileName = ""; // 保存新的文件名
		String nowTimeStr = ""; // 保存当前时间
		SimpleDateFormat sDateFormat;
		Random r = new Random();
		// String savePath =
		// ServletActionContext.getServletContext().getRealPath(
		// ""); // 获取项目根路径
		String savePath = ServletActionContext.getServletContext().getRealPath(
				"/upload/member/voice/");
		// savePath = savePath + "/file/";
		System.out.println("savePath" + savePath);
		// 生成随机文件名：当前年月日时分秒+五位随机数（为了在实际项目中防止文件同名而进行的处理）
		int rannum = (int) (r.nextDouble() * (99999 - 10000 + 1)) + 10000; // 获取随机数
		sDateFormat = new SimpleDateFormat("yyyyMMddHHmmss"); // 时间格式化的格式
		nowTimeStr = sDateFormat.format(new Date()); // 当前时间
		// 获取拓展名
		System.out.println("fileuploadFileName:" + fileuploadFileName);
		if (fileuploadFileName.lastIndexOf(".") >= 0) {
			extName = fileuploadFileName.substring(fileuploadFileName
					.lastIndexOf("."));
		}
		try {
			newFileName = nowTimeStr + rannum + extName; // 文件重命名后的名字
			// String filePath = savePath + "\\" + newFileName;
			String filePath = savePath + "/" + newFileName;
			System.out.println("filePath:--" + filePath);
			// filePath = filePath.replace("//", "/");
			// 检查上传的是否是语音
			System.out.println("extName" + extName);
			if (checkIsImage(extName)) {
				FileUtils.copyFile(fileupload, new File(filePath));
				System.out.println("fileupload:" + fileupload + "\t filePath:"
						+ filePath);
				response.getWriter().write(newFileName);
			} else {
				response.getWriter().write("fail");
			}
		} catch (IOException e) {
			e.printStackTrace();
			try {
				response.getWriter().write("error");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

		return null;
	}

	// 检查是否是图片格式
	public static boolean checkIsImage(String imgStr) {
		boolean flag = false;
		if (imgStr != null) {
			if (imgStr.equalsIgnoreCase(".mp3")
					|| imgStr.equalsIgnoreCase(".ogg")
					|| imgStr.equalsIgnoreCase(".wma")) {
				flag = true;
			}
		}
		return flag;
	}
}
