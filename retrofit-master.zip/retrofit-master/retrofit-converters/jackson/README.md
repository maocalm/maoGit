Jackson Converter
=================

A `Converter` which uses [Jackson][1] for serialization to and from JSON.

A default `ObjectMapper` instance will be created or one can be configured and passed to the
`JacksonConverter` construction to further control the serialization.


 [1]: http://wiki.fasterxml.com/JacksonHome
