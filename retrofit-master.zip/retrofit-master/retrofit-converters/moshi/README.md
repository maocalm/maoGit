Moshi Converter
===============

A `Converter` which uses [Moshi][1] for serialization to and from JSON.

A default `Moshi` instance will be created or one can be configured and passed to
`MoshiConverterFactory.create()` to further control the serialization.


 [1]: https://github.com/square/moshi
