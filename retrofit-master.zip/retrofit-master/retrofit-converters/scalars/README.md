Java Scalars Converter
======================

A `Converter` which supports converting strings and both primitives and their boxed types to
`text/plain` bodies.
