Wire Converter
==============

A `Converter` which uses [Wire][1] for protocol buffer-compatible serialization.


 [1]: https://github.com/square/wire
