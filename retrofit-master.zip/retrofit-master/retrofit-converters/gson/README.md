Gson Converter
==============

A `Converter` which uses [Gson][1] for serialization to and from JSON.

A default `Gson` instance will be created or one can be configured and passed to the
`GsonConverter` construction to further control the serialization.


 [1]: https://github.com/google/gson
