package com.recyclerview.demo;

import android.view.View;

/**
 * Created by Administrator on 2016/8/7.
 */
public interface MyItemClickListener {

    public void onItemClick(View view, int postion);

}
