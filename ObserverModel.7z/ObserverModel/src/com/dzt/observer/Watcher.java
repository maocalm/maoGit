package com.dzt.observer;  
//观察者  
public interface Watcher {  
    public void update(String str);  
}  