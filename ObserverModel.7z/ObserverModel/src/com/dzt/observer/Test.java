package com.dzt.observer;
public class Test {  
    public static void main(String[] args) {  
        //  Watched girl = new WatchedImpl();    
        WatchedImpl girl = new WatchedImpl();  
        Watcher watcher1 = new WatcherImpl();  
        Watcher watcher2 = new WatcherImpl();  
        Watcher watcher3 = new WatcherImpl();  
          
        girl.addWatcher(watcher1);  
        girl.addWatcher(watcher2);  
        girl.addWatcher(watcher3);  
          
        girl.notifyWatcher("hello");  
        girl.removeWatcher(watcher2);  
        girl.notifyWatcher("world");  
          
    }  
}  