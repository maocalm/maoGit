package com.dzt.observer;
import java.util.LinkedList;  
import java.util.List;  
  
public class WatchedImpl implements Watched {  
    private List<Watcher> list = new LinkedList<Watcher>();  
    @Override  
    public void addWatcher(Watcher watcher) {  
        list.add(watcher);  
    }  
  
    @Override  
    public void removeWatcher(Watcher watcher) {  
        list.remove(watcher);  
    }  
  
    @Override  
    public void notifyWatcher(String str) {  
        if(list.size()==0 || list==null)return;  
        for(Watcher watcher : list){  
            watcher.update(str);  
        }  
    }  
  
}  