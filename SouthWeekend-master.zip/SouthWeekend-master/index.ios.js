/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */


import Root from './app/root';

import { AppRegistry } from 'react-native';

AppRegistry.registerComponent('SouthWeekend', () => Root);
