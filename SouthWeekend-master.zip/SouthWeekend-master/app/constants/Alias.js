
export const CATEGORIES = {
  0: '头条',
  12: '调查',
  9: '时局',
  8: '视频',
  7: 'Hi,南周',
};
